import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppLayout } from '@/components/AppLayout';
import { Breadcrumb } from '@/components/Breadcrumb';
import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { UserPlus, Users, KeyRound, ArrowLeft } from 'lucide-react';
import { AlterarSenhaDialog } from '@/components/AlterarSenhaDialog';

export default function ConfiguracoesUsuario() {
  const navigate = useNavigate();
  const [senhaDialogOpen, setSenhaDialogOpen] = useState(false);
  const isAdmin = true; // TODO: Verificar perfil real do usuário

  return (
    <AppLayout>
      <Breadcrumb items={[
        { label: 'Menu', href: '/coleta/primeira' },
        { label: 'Configurações' }
      ]} />
      
      <PageHeader
        title="Configurações do Usuário"
        description={isAdmin ? "Gerencie usuários e parâmetros do sistema" : "Ajuste suas preferências pessoais"}
      />

      <div className="max-w-2xl space-y-4">
        <Card>
          <CardContent className="p-6 space-y-4">
            {isAdmin && (
              <>
                <Button
                  variant="outline"
                  className="h-auto py-6 flex-col items-start gap-2 w-full"
                  onClick={() => navigate('/usuarios/novo')}
                >
                  <div className="flex items-center gap-3 w-full">
                    <UserPlus className="h-5 w-5 text-title" />
                    <span className="text-lg font-medium text-title">Cadastrar novo usuário</span>
                  </div>
                  <span className="text-sm text-muted-foreground text-left">
                    Crie uma nova conta no sistema
                  </span>
                </Button>

                <Button
                  variant="outline"
                  className="h-auto py-6 flex-col items-start gap-2 w-full"
                  onClick={() => navigate('/usuarios')}
                >
                  <div className="flex items-center gap-3 w-full">
                    <Users className="h-5 w-5 text-title" />
                    <span className="text-lg font-medium text-title">Gerenciar usuários</span>
                  </div>
                  <span className="text-sm text-muted-foreground text-left">
                    Buscar, editar, redefinir senha e gerenciar status
                  </span>
                </Button>
              </>
            )}

            <Button
              variant="outline"
              className="h-auto py-6 flex-col items-start gap-2 w-full"
              onClick={() => setSenhaDialogOpen(true)}
            >
              <div className="flex items-center gap-3 w-full">
                <KeyRound className="h-5 w-5 text-title" />
                <span className="text-lg font-medium text-title">Mudar senha</span>
              </div>
              <span className="text-sm text-muted-foreground text-left">
                Alterar senha do usuário logado
              </span>
            </Button>
          </CardContent>
        </Card>

        <Button
          variant="outline"
          onClick={() => navigate('/coleta/primeira')}
          className="w-full"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar ao Menu
        </Button>
      </div>

      <AlterarSenhaDialog 
        open={senhaDialogOpen} 
        onOpenChange={setSenhaDialogOpen}
      />
    </AppLayout>
  );
}
