import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppLayout } from '@/components/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PageHeader } from '@/components/PageHeader';
import { useToast } from '@/hooks/use-toast';
import { db } from '@/lib/db';
import { useLiveQuery } from 'dexie-react-hooks';
import { formatCPF, validateCPF } from '@/lib/cpf';
import { format } from 'date-fns';
import { getAuthUser } from '@/lib/auth';

export default function Recoleta() {
  const [cpfOuRg, setCpfOuRg] = useState('');
  const [bebeId, setBebeId] = useState('');
  const [scannerId, setScannerId] = useState('');
  const [maeEncontrada, setMaeEncontrada] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [searching, setSearching] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const user = getAuthUser();

  const scanners = useLiveQuery(() => db.scanners.toArray().then(s => s.filter(scanner => scanner.ativo)));

  const bebes = useLiveQuery(
    () => {
      if (!maeEncontrada?.id) return Promise.resolve([]);
      return db.bebes.where('maeId').equals(maeEncontrada.id).toArray();
    },
    [maeEncontrada]
  );

  const handleBuscar = async () => {
    if (!cpfOuRg.trim()) {
      toast({
        title: 'Campo obrigatório',
        description: 'Informe o CPF ou RG da mãe.',
        variant: 'destructive',
      });
      return;
    }

    const numeros = cpfOuRg.replace(/\D/g, '');
    
    if (numeros.length === 11 && !validateCPF(cpfOuRg)) {
      toast({
        title: 'CPF inválido',
        description: 'Por favor, verifique o CPF informado.',
        variant: 'destructive',
      });
      return;
    }

    setSearching(true);
    setMaeEncontrada(null);
    setBebeId('');

    try {
      const mae = await db.maes.where('cpf').equals(numeros).first();

      if (!mae) {
        toast({
          title: 'Mãe não encontrada',
          description: 'Nenhum cadastro foi encontrado com este documento.',
          variant: 'destructive',
        });
      } else {
        setMaeEncontrada(mae);
        toast({
          title: 'Cadastro encontrado',
          description: `Mãe: ${mae.nome}`,
        });
      }
    } catch (error) {
      toast({
        title: 'Erro na busca',
        description: 'Não foi possível buscar o cadastro.',
        variant: 'destructive',
      });
    } finally {
      setSearching(false);
    }
  };

  const handleIniciar = async () => {
    if (!bebeId || !scannerId) {
      toast({
        title: 'Campos obrigatórios',
        description: 'Selecione o bebê e o scanner.',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);

    try {
      const sessaoId = await db.sessoesColeta.add({
        usuarioId: user!.id,
        maeId: maeEncontrada!.id!,
        bebeId: parseInt(bebeId),
        scannerId: parseInt(scannerId),
        tipoSessao: 'RECOLETA',
        matchingHabilitado: false,
        dataInicio: new Date(),
        status: 'EM_ANDAMENTO',
        syncStatus: 'PENDENTE',
        createdAt: new Date()
      });

      toast({
        title: 'Sessão iniciada',
        description: 'Recoleta iniciada com sucesso.',
      });

      navigate(`/coleta/sessao/${sessaoId}/captura`);
    } catch (error) {
      toast({
        title: 'Erro ao iniciar',
        description: 'Não foi possível iniciar a recoleta.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppLayout>
      <PageHeader 
        title="Recoleta"
        description="Busque o cadastro da mãe para iniciar a recoleta"
      />

      <Card className="max-w-2xl">
        <CardHeader>
          <CardTitle>Buscar Cadastro</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="cpfOuRg">CPF ou RG *</Label>
            <div className="flex gap-2">
              <Input
                id="cpfOuRg"
                value={cpfOuRg}
                onChange={(e) => setCpfOuRg(e.target.value)}
                placeholder="Digite o CPF ou RG"
                required
              />
              <Button onClick={handleBuscar} disabled={searching}>
                {searching ? 'Buscando...' : 'Buscar'}
              </Button>
            </div>
          </div>

          {maeEncontrada && (
            <>
              <div className="p-4 bg-muted rounded-lg">
                <p className="font-semibold">Mãe encontrada:</p>
                <p className="text-sm">{maeEncontrada.nome}</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bebe">Selecione o bebê *</Label>
                <Select value={bebeId} onValueChange={setBebeId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Escolha o bebê" />
                  </SelectTrigger>
                  <SelectContent>
                    {bebes?.map((bebe) => (
                      <SelectItem key={bebe.id} value={bebe.id!.toString()}>
                        Nascimento: {format(new Date(bebe.dataNascimento), 'dd/MM/yyyy HH:mm:ss')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="scanner">Selecione o scanner *</Label>
                <Select value={scannerId} onValueChange={setScannerId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Escolha um scanner" />
                  </SelectTrigger>
                  <SelectContent>
                    {scanners?.map((scanner) => (
                      <SelectItem key={scanner.id} value={scanner.id!.toString()}>
                        {scanner.nome} - {scanner.modelo}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="pt-4">
                <Button 
                  onClick={handleIniciar} 
                  disabled={!bebeId || !scannerId || loading}
                  className="w-full"
                >
                  {loading ? 'Iniciando...' : 'Iniciar Recoleta'}
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </AppLayout>
  );
}
