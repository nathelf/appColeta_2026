import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { UserCog } from 'lucide-react';
import { routes } from '@/lib/routes';
import { getAuthUser } from '@/lib/auth';
import { FingerprintBackground } from '@/components/FingerprintBackground';

export default function MenuColeta() {
  const navigate = useNavigate();
  const user = getAuthUser();

  return (
    <div className="min-h-screen bg-[#e8e4dc] flex items-center justify-center p-4 relative">
      <FingerprintBackground />
      
      <div className="relative z-10 w-full max-w-5xl">
        {/* User settings icon */}
        <div className="absolute top-0 left-0">
          <button
            onClick={() => navigate('/config/usuario')}
            className="w-12 h-12 bg-secondary/90 hover:bg-secondary rounded-lg flex items-center justify-center shadow-lg transition-colors"
          >
            <UserCog className="h-6 w-6 text-secondary-foreground" />
          </button>
        </div>

        {/* Main content grid */}
        <div className="grid md:grid-cols-2 gap-8 pt-16">
          {/* Primeira Coleta */}
          <Card 
            onClick={() => navigate(routes.coleta.primeira)}
            className="cursor-pointer hover:shadow-2xl transition-all hover:scale-105 bg-[#f5f1e8] border-0 overflow-hidden"
          >
            <CardHeader className="text-center pb-0">
              <CardTitle className="text-4xl font-bold text-primary mb-4">
                Primeira Coleta
              </CardTitle>
            </CardHeader>
            <div className="p-6 flex justify-center">
              <div className="w-64 h-64 bg-white rounded-2xl shadow-inner flex items-center justify-center">
                <svg viewBox="0 0 200 200" className="w-full h-full p-4">
                  {/* Baby illustration - simplified */}
                  <circle cx="100" cy="60" r="30" fill="#a8c5dd" />
                  <ellipse cx="100" cy="120" r="40" ry="50" fill="#a8c5dd" />
                  <circle cx="90" cy="55" r="3" fill="#000" />
                  <circle cx="110" cy="55" r="3" fill="#000" />
                  <path d="M 90 65 Q 100 70 110 65" stroke="#000" strokeWidth="2" fill="none" />
                  {/* Scanner device */}
                  <rect x="120" y="140" width="40" height="30" rx="5" fill="#4a4a4a" />
                  <rect x="125" y="145" width="30" height="20" fill="#6b8e23" opacity="0.5" />
                  {/* Arrow */}
                  <path d="M 100 100 L 135 135" stroke="#000" strokeWidth="3" markerEnd="url(#arrowhead)" />
                  <defs>
                    <marker id="arrowhead" markerWidth="10" markerHeight="10" refX="5" refY="5" orient="auto">
                      <polygon points="0 0, 10 5, 0 10" fill="#000" />
                    </marker>
                  </defs>
                </svg>
              </div>
            </div>
          </Card>

          {/* Recoleta */}
          <Card 
            onClick={() => navigate(routes.coleta.recoleta)}
            className="cursor-pointer hover:shadow-2xl transition-all hover:scale-105 bg-[#f5f1e8] border-0 overflow-hidden"
          >
            <CardHeader className="text-center pb-0">
              <CardTitle className="text-4xl font-bold text-primary mb-4">
                Recoleta
              </CardTitle>
            </CardHeader>
            <div className="p-6 flex justify-center">
              <div className="w-64 h-64 bg-white rounded-2xl shadow-inner flex items-center justify-center">
                <svg viewBox="0 0 200 200" className="w-full h-full p-4">
                  {/* Baby illustration - orange tones */}
                  <circle cx="100" cy="60" r="30" fill="#dd9f6f" />
                  <ellipse cx="100" cy="120" r="40" ry="50" fill="#dd9f6f" />
                  <circle cx="90" cy="55" r="3" fill="#000" />
                  <circle cx="110" cy="55" r="3" fill="#000" />
                  <path d="M 90 65 Q 100 70 110 65" stroke="#000" strokeWidth="2" fill="none" />
                  {/* Scanner with X mark */}
                  <rect x="140" y="120" width="50" height="40" rx="5" fill="#8b7355" />
                  <circle cx="165" cy="140" r="15" fill="#6b8e23" opacity="0.5" />
                  <g transform="translate(145, 95)">
                    <rect x="0" y="0" width="35" height="30" rx="5" fill="#f5deb3" stroke="#000" strokeWidth="2" />
                    <line x1="5" y1="5" x2="30" y2="25" stroke="#d32f2f" strokeWidth="3" />
                    <line x1="30" y1="5" x2="5" y2="25" stroke="#d32f2f" strokeWidth="3" />
                  </g>
                  {/* Arrow */}
                  <path d="M 100 100 L 145 125" stroke="#000" strokeWidth="3" markerEnd="url(#arrowhead2)" />
                  <defs>
                    <marker id="arrowhead2" markerWidth="10" markerHeight="10" refX="5" refY="5" orient="auto">
                      <polygon points="0 0, 10 5, 0 10" fill="#000" />
                    </marker>
                  </defs>
                </svg>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
