import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Lock, User, Eye, EyeOff } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { validateLogin, setAuthUser, getAuthUser } from '@/lib/auth';
import { ForgotPasswordDialog } from '@/components/ForgotPasswordDialog';
import { FingerprintBackground } from '@/components/FingerprintBackground';
import biometriaLogo from '@/assets/biometria-logo.png';

export default function Login() {
  const [usuario, setUsuario] = useState('');
  const [senha, setSenha] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [forgotPasswordOpen, setForgotPasswordOpen] = useState(false);

  const usuarioRef = useRef<HTMLInputElement | null>(null);
  const senhaRef = useRef<HTMLInputElement | null>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  // Se já estiver logado → dashboard
  useEffect(() => {
    const user = getAuthUser();
    if (user) {
      navigate('/dashboard', { replace: true });
    } else {
      usuarioRef.current?.focus();
    }
  }, [navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    const username = usuario.trim();
    const password = senha;

    if (!username || !password) {
      toast({
        title: 'Preencha todos os campos',
        description: 'Informe usuário e senha.',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);

    try {
      const result = await validateLogin(username, password);

      if (result.success && result.user) {
        setAuthUser(result.user);

        toast({
          title: 'Login realizado',
          description: `Bem-vindo(a), ${result.user.name}!`,
        });

        // 🔵 AQUI MANTEMOS O QUE VOCÊ PEDIU:
        navigate('/termo-de-uso', { replace: true });

      } else {
        toast({
          title: 'Erro no login',
          description: result.message || 'Usuário ou senha inválidos.',
          variant: 'destructive',
        });

        setSenha('');
        senhaRef.current?.focus();
      }
    } catch (error) {
      toast({
        title: 'Erro no login',
        description: 'Falha de conexão. Tente novamente.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const isFormValid = usuario.trim().length > 0 && senha.trim().length > 0;

  return (
    <>
      <div className="min-h-screen bg-[#e8e4dc] flex items-center justify-center p-4 relative">
        <FingerprintBackground />

        <Card
          className="w-full max-w-md bg-modal/95 backdrop-blur-sm border-0 shadow-2xl"
          role="region"
          aria-label="Formulário de login"
        >
          <CardHeader className="space-y-4 text-center pb-4">
            <div className="flex justify-center">
              <img
                src={biometriaLogo}
                alt="Logo Sistema de Coleta Biométrica Neonatal"
                className="w-24 h-24 object-contain"
              />
            </div>

            <div>
              <CardTitle className="text-2xl font-bold text-primary">
                Sistema de Coleta Biométrica Neonatal
              </CardTitle>
              <CardDescription className="text-card-foreground/80 mt-2">
                Faça login para continuar
              </CardDescription>
            </div>
          </CardHeader>

          <form onSubmit={handleLogin} noValidate>
            <CardContent className="space-y-4 pt-0">
              <div className="space-y-2">
                <Label htmlFor="usuario">Usuário</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" aria-hidden />
                  <Input
                    id="usuario"
                    ref={usuarioRef}
                    type="text"
                    placeholder="Informe o usuário"
                    value={usuario}
                    onChange={(e) => setUsuario(e.target.value)}
                    className="pl-10"
                    autoComplete="username"
                    aria-label="Usuário"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="senha">Senha</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" aria-hidden />
                  <Input
                    id="senha"
                    ref={senhaRef}
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={senha}
                    onChange={(e) => setSenha(e.target.value)}
                    className="pl-10 pr-10"
                    autoComplete="current-password"
                    aria-label="Senha"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
                    aria-pressed={showPassword}
                    className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setForgotPasswordOpen(true)}
                className="text-sm text-primary hover:underline font-medium"
              >
                Esqueceu a senha?
              </button>
            </CardContent>

            <CardFooter className="pt-2">
              <Button
                type="submit"
                className="w-full font-bold text-lg h-12 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg"
                disabled={loading || !isFormValid}
              >
                {loading ? 'Entrando...' : 'Entrar'}
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>

      <ForgotPasswordDialog open={forgotPasswordOpen} onOpenChange={setForgotPasswordOpen} />
    </>
  );
}
