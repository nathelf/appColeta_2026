import { Check } from 'lucide-react';

interface Finger {
  tipo: string;
  status: 'pending' | 'capturing' | 'captured' | 'skipped';
}

interface HandDiagramProps {
  hand: 'DIREITA' | 'ESQUERDA';
  isActive: boolean;
  currentFingerIndex: number;
  fingers: Finger[];
}

export function HandDiagram({ hand, isActive, currentFingerIndex, fingers }: HandDiagramProps) {
  const fingerLabels = ['P', 'I', 'M', 'A', 'Mi'];
  const fingerNames = ['POLEGAR', 'INDICADOR', 'MEDIO', 'ANELAR', 'MINDINHO'];
  
  // Positions based on the reference image
  // Right hand (from baby's perspective facing collector): thumb bottom-right, fingers curve left
  // Left hand (from baby's perspective facing collector): thumb bottom-left, fingers curve right
  const getFingerPosition = (index: number) => {
    if (hand === 'DIREITA') {
      // Right hand - thumb on bottom right, fingers arranged in arc
      const positions = [
        { x: 70, y: 80 },   // P - Polegar (bottom right)
        { x: 80, y: 40 },   // I - Indicador (right side upper)
        { x: 60, y: 25 },   // M - Médio (top center-right)
        { x: 40, y: 35 },   // A - Anelar (upper left)
        { x: 20, y: 50 },   // Mi - Mindinho (left side)
      ];
      return positions[index];
    } else {
      // Left hand - thumb on bottom left, fingers arranged in arc (mirrored)
      const positions = [
        { x: 30, y: 80 },   // P - Polegar (bottom left)
        { x: 20, y: 40 },   // I - Indicador (left side upper)
        { x: 40, y: 25 },   // M - Médio (top center-left)
        { x: 60, y: 35 },   // A - Anelar (upper right)
        { x: 80, y: 50 },   // Mi - Mindinho (right side)
      ];
      return positions[index];
    }
  };

  const getFingerStatus = (index: number) => {
    const fingerType = fingerNames[index];
    const finger = fingers.find(f => f.tipo === fingerType);
    if (!finger) return 'pending';
    
    // Check if this is the current finger being selected
    const currentFinger = fingers[currentFingerIndex];
    if (currentFinger && currentFinger.tipo === fingerType && isActive) {
      return 'current';
    }
    
    return finger.status;
  };

  const getFingerStyle = (status: string, size: 'normal' | 'large' = 'normal') => {
    const baseSize = size === 'large' ? 'w-8 h-8 text-xs' : 'w-6 h-6 text-[10px]';
    const baseClasses = `${baseSize} rounded-full flex items-center justify-center font-bold transition-all`;
    
    switch (status) {
      case 'current':
        return `${baseClasses} bg-primary text-primary-foreground ring-2 ring-primary/30 scale-110`;
      case 'captured':
        return `${baseClasses} bg-green-500 text-white`;
      case 'capturing':
        return `${baseClasses} bg-blue-500 text-white animate-pulse`;
      case 'skipped':
        return `${baseClasses} bg-yellow-500 text-white`;
      default:
        return `${baseClasses} bg-muted border-2 border-muted-foreground/30 text-muted-foreground`;
    }
  };

  return (
    <div className={`relative p-2 rounded-lg border-2 transition-all ${
      isActive ? 'border-primary bg-primary/5' : 'border-border bg-card'
    }`}>
      <h4 className={`text-center text-xs font-medium mb-1 ${
        isActive ? 'text-primary' : 'text-muted-foreground'
      }`}>
        Mão {hand === 'DIREITA' ? 'Direita' : 'Esquerda'}
      </h4>
      
      {/* Hand diagram area - more compact */}
      <div className="relative w-full aspect-square max-w-[120px] mx-auto">
        {/* Finger circles positioned to form hand shape */}
        {fingerLabels.map((label, index) => {
          const pos = getFingerPosition(index);
          const status = getFingerStatus(index);
          const isCurrent = status === 'current';
          
          return (
            <div
              key={index}
              className={`absolute ${getFingerStyle(status, isCurrent ? 'large' : 'normal')}`}
              style={{
                left: `${pos.x}%`,
                top: `${pos.y}%`,
                transform: 'translate(-50%, -50%)'
              }}
            >
              {status === 'captured' ? (
                <Check className="w-3 h-3" />
              ) : (
                label
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
